package com.fakefarmers;

import net.minecraft.core.UUIDUtil;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.players.NameAndId;
import net.minecraft.server.players.OldUsersConverter;
import net.minecraft.server.players.PlayerList;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Entscheidet, ob ein Name als Bot gespawnt werden darf.
 *
 * Blockiert werden:
 *  - gebannte Spieler (immer)
 *  - Namen ehemaliger/echter Spieler dieses Servers (wenn blockFormerPlayerNames aktiv ist):
 *    bekannte echte Spieler, vorhandene Spielerdaten, Operatoren, Whitelist-Eintraege.
 */
public final class NameGuard {

	public record Result(UUID uuid, String blockReason) {
		public boolean allowed() {
			return blockReason == null;
		}
	}

	private NameGuard() {
	}

	public static Result check(MinecraftServer server, String name, boolean blockFormerPlayers) {
		UUID offline = UUIDUtil.createOfflinePlayerUUID(name);
		UUID primary = null;
		try {
			// Im Online-Modus: echte Mojang-UUID (blockierender Lookup, wie bei Carpet). Sonst null.
			primary = OldUsersConverter.convertMobOwnerIfNecessary(server, name);
		} catch (Exception e) {
			FakeFarmersMod.LOGGER.debug("UUID-Lookup fuer {} fehlgeschlagen, verwende Offline-UUID.", name, e);
		}
		if (primary == null) {
			primary = offline;
		}

		List<NameAndId> candidates = new ArrayList<>(2);
		candidates.add(new NameAndId(primary, name));
		if (!offline.equals(primary)) {
			candidates.add(new NameAndId(offline, name));
		}

		PlayerList playerList = server.getPlayerList();

		for (NameAndId candidate : candidates) {
			if (playerList.getBans().isBanned(candidate)) {
				return new Result(primary, "'" + name + "' ist auf diesem Server gebannt.");
			}
		}

		if (!blockFormerPlayers) {
			return new Result(primary, null);
		}

		if (PlayerRegistry.isKnownRealPlayer(name)) {
			return new Result(primary, blocked(name));
		}
		if (PlayerRegistry.isKnownBot(name)) {
			// Wurde von dieser Mod schon als Bot benutzt -> gespeicherte Daten gehoeren dem Bot.
			return new Result(primary, null);
		}

		for (NameAndId candidate : candidates) {
			if (playerList.loadPlayerData(candidate).isPresent()
				|| playerList.isOp(candidate)
				|| (playerList.isUsingWhitelist() && playerList.isWhiteListed(candidate))) {
				return new Result(primary, blocked(name));
			}
		}

		return new Result(primary, null);
	}

	private static String blocked(String name) {
		return "'" + name + "' war bereits als echter Spieler auf diesem Server und darf nicht als Bot gespawnt werden.";
	}
}
