package com.fakefarmers.command;

import com.fakefarmers.FakeFarmersConfig;
import com.fakefarmers.NameGuard;
import com.fakefarmers.player.FakePlayerActionPack;
import com.fakefarmers.player.FakePlayerActionPack.Action;
import com.fakefarmers.player.FakePlayerActionPack.ActionType;
import com.fakefarmers.player.FakePlayerEntity;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;
import static net.minecraft.commands.SharedSuggestionProvider.suggest;

/**
 * /fakeplayer (Alias: /fp)
 *
 * Verwaltung:
 *   spawn <name> [at <pos>] | kill <name> | killall | list | limit [zahl] | allowformernames [true|false]
 * Berechtigung (nur Operatoren):
 *   permission list | permission add <spieler> | permission remove <name>
 * Steuerung (pro Bot):
 *   <name> attack|use|jump once|continuous|interval <ticks>|stop
 *   <name> sneak|sprint true|false
 *   <name> move forward|backward|left|right|stop
 *   <name> look north|south|east|west|up|down
 *   <name> hotbar <1-9> | drop [all] | status | stop | kill
 */
public final class FakePlayerCommand {

	private static final Pattern VALID_NAME = Pattern.compile("[A-Za-z0-9_]{1,16}");

	private FakePlayerCommand() {
	}

	public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
		LiteralArgumentBuilder<CommandSourceStack> root = literal("fakeplayer")
			.requires(FakePlayerCommand::isAllowed)

			// ---- Verwaltung ----
			.then(literal("spawn")
				.then(argument("name", word())
					.executes(FakePlayerCommand::spawnAtSender)
					.then(literal("at")
						.then(argument("position", Vec3Argument.vec3())
							.executes(FakePlayerCommand::spawnAtPosition)))))
			.then(literal("list").executes(FakePlayerCommand::list))
			.then(literal("killall").executes(FakePlayerCommand::killAll))
			.then(literal("limit")
				.executes(FakePlayerCommand::showLimit)
				.then(argument("amount", IntegerArgumentType.integer(0, 1000))
					.requires(FakePlayerCommand::isAdmin)
					.executes(FakePlayerCommand::setLimit)))
			.then(literal("allowformernames")
				.requires(FakePlayerCommand::isAdmin)
				.executes(FakePlayerCommand::showAllowFormerNames)
				.then(argument("value", BoolArgumentType.bool())
					.executes(FakePlayerCommand::setAllowFormerNames)))

			// ---- Berechtigungen (nur Operatoren) ----
			.then(literal("permission")
				.requires(FakePlayerCommand::isAdmin)
				.then(literal("list").executes(FakePlayerCommand::permissionList))
				.then(literal("add")
					.then(argument("target", EntityArgument.player())
						.executes(FakePlayerCommand::permissionAdd)))
				.then(literal("remove")
					.then(argument("target", word())
						.suggests((ctx, builder) -> suggest(FakeFarmersConfig.get().allowedPlayers.values(), builder))
						.executes(FakePlayerCommand::permissionRemove))))

			// ---- Steuerung eines einzelnen Bots ----
			.then(argument("name", word())
				.suggests((ctx, builder) -> suggest(botNames(ctx.getSource()), builder))
				.then(literal("kill").executes(FakePlayerCommand::kill))
				.then(literal("stop").executes(act(ap -> ap.stopAll(), "Alle Aktionen gestoppt")))
				.then(literal("status").executes(FakePlayerCommand::status))
				.then(actionNode("attack", ActionType.ATTACK))
				.then(actionNode("use", ActionType.USE))
				.then(actionNode("jump", ActionType.JUMP))
				.then(literal("sneak")
					.then(literal("true").executes(act(ap -> ap.setSneaking(true), "Schleicht")))
					.then(literal("false").executes(act(ap -> ap.setSneaking(false), "Schleicht nicht mehr"))))
				.then(literal("sprint")
					.then(literal("true").executes(act(ap -> ap.setSprinting(true), "Sprintet")))
					.then(literal("false").executes(act(ap -> ap.setSprinting(false), "Sprintet nicht mehr"))))
				.then(literal("move")
					.then(literal("forward").executes(act(ap -> ap.setForward(1), "Laeuft vorwaerts")))
					.then(literal("backward").executes(act(ap -> ap.setForward(-1), "Laeuft rueckwaerts")))
					.then(literal("left").executes(act(ap -> ap.setStrafing(1), "Laeuft nach links")))
					.then(literal("right").executes(act(ap -> ap.setStrafing(-1), "Laeuft nach rechts")))
					.then(literal("stop").executes(act(ap -> ap.stopMovement(), "Bewegung gestoppt"))))
				.then(literal("look")
					.then(literal("north").executes(act(ap -> ap.look(Direction.NORTH), "Schaut nach Norden")))
					.then(literal("south").executes(act(ap -> ap.look(Direction.SOUTH), "Schaut nach Sueden")))
					.then(literal("east").executes(act(ap -> ap.look(Direction.EAST), "Schaut nach Osten")))
					.then(literal("west").executes(act(ap -> ap.look(Direction.WEST), "Schaut nach Westen")))
					.then(literal("up").executes(act(ap -> ap.look(Direction.UP), "Schaut nach oben")))
					.then(literal("down").executes(act(ap -> ap.look(Direction.DOWN), "Schaut nach unten"))))
				.then(literal("hotbar")
					.then(argument("slot", IntegerArgumentType.integer(1, 9))
						.executes(ctx -> {
							int slot = IntegerArgumentType.getInteger(ctx, "slot");
							return act(ap -> ap.setSlot(slot), "Hotbar-Slot " + slot + " gewaehlt").run(ctx);
						})))
				.then(literal("drop")
					.executes(act(ap -> ap.dropSelected(false), "Item abgeworfen"))
					.then(literal("stack").executes(act(ap -> ap.dropSelected(true), "Stack abgeworfen")))
					.then(literal("all").executes(act(ap -> ap.dropEverything(), "Inventar abgeworfen")))));

		dispatcher.register(root);
		// Kurzform /fp
		dispatcher.register(literal("fp")
			.requires(FakePlayerCommand::isAllowed)
			.redirect(dispatcher.getRoot().getChild("fakeplayer")));
	}

	/** attack|use|jump once | continuous | interval <ticks> | stop */
	private static ArgumentBuilder<CommandSourceStack, ?> actionNode(String name, ActionType type) {
		return literal(name)
			.executes(act(ap -> ap.start(type, Action.once()), name + ": einmal ausgefuehrt"))
			.then(literal("once").executes(act(ap -> ap.start(type, Action.once()), name + ": einmal ausgefuehrt")))
			.then(literal("continuous").executes(act(ap -> ap.start(type, Action.continuous()), name + ": dauerhaft aktiv")))
			.then(literal("interval")
				.then(argument("ticks", IntegerArgumentType.integer(1, 72000))
					.executes(ctx -> {
						int ticks = IntegerArgumentType.getInteger(ctx, "ticks");
						return act(ap -> ap.start(type, Action.interval(ticks)),
							name + ": alle " + ticks + " Ticks").run(ctx);
					})))
			.then(literal("stop").executes(act(ap -> ap.start(type, null), name + ": gestoppt")));
	}

	// ------------------------------------------------------------------ Hilfsfunktionen

	@FunctionalInterface
	private interface PackAction {
		void apply(FakePlayerActionPack pack);
	}

	/** Fuehrt eine Aktion am benannten Bot aus und meldet Erfolg/Fehler. */
	private static Command<CommandSourceStack> act(PackAction action, String successMessage) {
		return ctx -> {
			FakePlayerEntity bot = resolveBot(ctx);
			if (bot == null) {
				return 0;
			}
			action.apply(bot.actionPack);
			ctx.getSource().sendSuccess(() -> Component.literal(botName(bot) + ": " + successMessage), false);
			return 1;
		};
	}

	// ------------------------------------------------------------------ Berechtigungen

	/** Operator (Level 2), Konsole oder Command-Block. */
	private static boolean isAdmin(CommandSourceStack source) {
		return Commands.LEVEL_GAMEMASTERS.check(source.permissions());
	}

	/** Darf Bots benutzen: Operatoren oder Spieler auf der Erlaubt-Liste. */
	private static boolean isAllowed(CommandSourceStack source) {
		if (isAdmin(source)) {
			return true;
		}
		return source.getEntity() instanceof ServerPlayer player
			&& FakeFarmersConfig.get().allowedPlayers.containsKey(player.getUUID().toString());
	}

	/** Operatoren steuern alle Bots, alle anderen nur ihre eigenen. */
	private static boolean canControl(CommandSourceStack source, FakePlayerEntity bot) {
		if (isAdmin(source)) {
			return true;
		}
		return source.getEntity() instanceof ServerPlayer player && player.getUUID().equals(bot.ownerUuid);
	}

	/** Findet den im Befehl genannten Bot; meldet selbst Fehler und gibt dann null zurueck. */
	private static FakePlayerEntity resolveBot(CommandContext<CommandSourceStack> ctx) {
		String name = getString(ctx, "name");
		ServerPlayer player = ctx.getSource().getServer().getPlayerList().getPlayerByName(name);
		if (!(player instanceof FakePlayerEntity bot)) {
			ctx.getSource().sendFailure(Component.literal(
				"Kein Fake-Spieler mit dem Namen '" + name + "' gefunden. (/fakeplayer list)"));
			return null;
		}
		if (!canControl(ctx.getSource(), bot)) {
			ctx.getSource().sendFailure(Component.literal("Der Bot '" + name + "' gehoert dir nicht."));
			return null;
		}
		return bot;
	}

	private static String botName(FakePlayerEntity bot) {
		return bot.getGameProfile().name();
	}

	/** Alle Bots auf dem Server (fuer das Limit). */
	private static List<FakePlayerEntity> allBots(MinecraftServer server) {
		return server.getPlayerList().getPlayers().stream()
			.filter(p -> p instanceof FakePlayerEntity)
			.map(p -> (FakePlayerEntity) p)
			.toList();
	}

	/** Bots, die der Sender steuern darf. */
	private static List<FakePlayerEntity> controllableBots(CommandSourceStack source) {
		return allBots(source.getServer()).stream()
			.filter(bot -> canControl(source, bot))
			.toList();
	}

	private static List<String> botNames(CommandSourceStack source) {
		return controllableBots(source).stream().map(FakePlayerCommand::botName).toList();
	}

	// ------------------------------------------------------------------ Spawn

	private static int spawnAtSender(CommandContext<CommandSourceStack> ctx) {
		return trySpawn(ctx, ctx.getSource().getPosition());
	}

	private static int spawnAtPosition(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
		return trySpawn(ctx, Vec3Argument.getVec3(ctx, "position"));
	}

	private static int trySpawn(CommandContext<CommandSourceStack> ctx, Vec3 pos) {
		CommandSourceStack source = ctx.getSource();
		MinecraftServer server = source.getServer();
		FakeFarmersConfig config = FakeFarmersConfig.get();
		String name = getString(ctx, "name");

		if (!VALID_NAME.matcher(name).matches()) {
			source.sendFailure(Component.literal(
				"Ungueltiger Name '" + name + "' (erlaubt: Buchstaben, Zahlen, _ ; max. 16 Zeichen)."));
			return 0;
		}
		if (FakePlayerEntity.isSpawning(name) || server.getPlayerList().getPlayerByName(name) != null) {
			source.sendFailure(Component.literal("Ein Spieler mit dem Namen '" + name + "' ist bereits online."));
			return 0;
		}

		int active = allBots(server).size() + FakePlayerEntity.spawningCount();
		if (active >= config.maxBots) {
			source.sendFailure(Component.literal(
				"Bot-Limit erreicht (" + config.maxBots + "). Erhoehen mit /fakeplayer limit <zahl>."));
			return 0;
		}

		NameGuard.Result guard = NameGuard.check(server, name, config.blockFormerPlayerNames);
		if (!guard.allowed()) {
			source.sendFailure(Component.literal(guard.blockReason()));
			return 0;
		}

		if (!Level.isInSpawnableBounds(BlockPos.containing(pos))) {
			source.sendFailure(Component.literal("Diese Position liegt ausserhalb der Welt."));
			return 0;
		}

		Vec2 rotation = source.getRotation();
		ResourceKey<Level> dimension = source.getLevel().dimension();

		GameType gameMode = GameType.SURVIVAL;
		boolean flying = false;
		UUID owner = null;
		if (source.getEntity() instanceof ServerPlayer sender) {
			owner = sender.getUUID();
			gameMode = sender.gameMode.getGameModeForPlayer();
			flying = sender.getAbilities().flying;
		}
		if (gameMode == GameType.SPECTATOR) {
			flying = true;
		} else if (gameMode.isSurvival()) {
			flying = false;
		}

		FakePlayerEntity.spawn(server, name, guard.uuid(), owner, pos, rotation.y, rotation.x, dimension, gameMode, flying);
		source.sendSuccess(() -> Component.literal("Fake-Spieler '" + name + "' wird gespawnt ..."), true);
		return 1;
	}

	// ------------------------------------------------------------------ Entfernen / Liste / Status

	private static int kill(CommandContext<CommandSourceStack> ctx) {
		FakePlayerEntity bot = resolveBot(ctx);
		if (bot == null) {
			return 0;
		}
		String name = botName(bot);
		bot.kill(Component.literal("Entfernt"));
		ctx.getSource().sendSuccess(() -> Component.literal("Fake-Spieler '" + name + "' entfernt."), true);
		return 1;
	}

	/** Entfernt alle Bots, die der Sender steuern darf (Operatoren: alle). */
	private static int killAll(CommandContext<CommandSourceStack> ctx) {
		List<FakePlayerEntity> bots = controllableBots(ctx.getSource());
		for (FakePlayerEntity bot : bots) {
			bot.kill(Component.literal("Entfernt"));
		}
		int count = bots.size();
		ctx.getSource().sendSuccess(() -> Component.literal(count + " Fake-Spieler entfernt."), true);
		return count;
	}

	private static int list(CommandContext<CommandSourceStack> ctx) {
		CommandSourceStack source = ctx.getSource();
		List<String> names = botNames(source);
		int total = allBots(source.getServer()).size();
		int limit = FakeFarmersConfig.get().maxBots;
		if (names.isEmpty()) {
			source.sendSuccess(() -> Component.literal(
				"Keine Fake-Spieler fuer dich (gesamt auf dem Server: " + total + "/" + limit + ")."), false);
		} else {
			source.sendSuccess(() -> Component.literal(
				"Fake-Spieler (" + names.size() + "; gesamt " + total + "/" + limit + "): " + String.join(", ", names)), false);
		}
		return names.size();
	}

	private static int status(CommandContext<CommandSourceStack> ctx) {
		FakePlayerEntity bot = resolveBot(ctx);
		if (bot == null) {
			return 0;
		}
		String description = bot.actionPack.describe();
		ctx.getSource().sendSuccess(() -> Component.literal(botName(bot) + ": " + description), false);
		return 1;
	}

	// ------------------------------------------------------------------ Berechtigungen verwalten

	private static int permissionList(CommandContext<CommandSourceStack> ctx) {
		List<String> names = List.copyOf(FakeFarmersConfig.get().allowedPlayers.values());
		ctx.getSource().sendSuccess(() -> Component.literal(names.isEmpty()
			? "Erlaubt-Liste ist leer (nur Operatoren duerfen Bots spawnen)."
			: "Duerfen Bots spawnen (" + names.size() + "): " + String.join(", ", names)
				+ " (+ alle Operatoren)"), false);
		return names.size();
	}

	private static int permissionAdd(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
		ServerPlayer target = EntityArgument.getPlayer(ctx, "target");
		if (target instanceof FakePlayerEntity) {
			ctx.getSource().sendFailure(Component.literal("Ein Bot kann nicht auf die Liste."));
			return 0;
		}
		FakeFarmersConfig config = FakeFarmersConfig.get();
		String name = target.getGameProfile().name();
		String previous = config.allowedPlayers.put(target.getUUID().toString(), name);
		config.save();
		ctx.getSource().sendSuccess(() -> Component.literal(previous == null
			? name + " darf jetzt Bots spawnen und seine eigenen Bots steuern."
			: name + " stand schon auf der Liste."), true);
		return 1;
	}

	private static int permissionRemove(CommandContext<CommandSourceStack> ctx) {
		String input = getString(ctx, "target");
		FakeFarmersConfig config = FakeFarmersConfig.get();
		boolean removed = config.allowedPlayers.entrySet().removeIf(
			e -> e.getValue().equalsIgnoreCase(input) || e.getKey().equalsIgnoreCase(input));
		if (!removed) {
			ctx.getSource().sendFailure(Component.literal("'" + input + "' steht nicht auf der Liste. (/fakeplayer permission list)"));
			return 0;
		}
		config.save();
		ctx.getSource().sendSuccess(() -> Component.literal(
			input + " darf keine Bots mehr spawnen. Bereits gespawnte Bots bleiben bestehen (Entfernen: /fakeplayer <name> kill)."), true);
		return 1;
	}

	// ------------------------------------------------------------------ Einstellungen

	private static int showLimit(CommandContext<CommandSourceStack> ctx) {
		int limit = FakeFarmersConfig.get().maxBots;
		ctx.getSource().sendSuccess(() -> Component.literal("Aktuelles Bot-Limit: " + limit), false);
		return limit;
	}

	private static int setLimit(CommandContext<CommandSourceStack> ctx) {
		int amount = IntegerArgumentType.getInteger(ctx, "amount");
		FakeFarmersConfig config = FakeFarmersConfig.get();
		config.maxBots = amount;
		config.save();
		ctx.getSource().sendSuccess(() -> Component.literal("Bot-Limit auf " + amount + " gesetzt."), true);
		return amount;
	}

	private static int showAllowFormerNames(CommandContext<CommandSourceStack> ctx) {
		boolean blocked = FakeFarmersConfig.get().blockFormerPlayerNames;
		ctx.getSource().sendSuccess(() -> Component.literal(blocked
			? "Namen ehemaliger Spieler sind blockiert (Standard)."
			: "Namen ehemaliger Spieler sind erlaubt."), false);
		return blocked ? 0 : 1;
	}

	private static int setAllowFormerNames(CommandContext<CommandSourceStack> ctx) {
		boolean allow = BoolArgumentType.getBool(ctx, "value");
		FakeFarmersConfig config = FakeFarmersConfig.get();
		config.blockFormerPlayerNames = !allow;
		config.save();
		ctx.getSource().sendSuccess(() -> Component.literal(allow
			? "Namen ehemaliger Spieler sind jetzt ERLAUBT."
			: "Namen ehemaliger Spieler sind jetzt blockiert."), true);
		return 1;
	}
}
