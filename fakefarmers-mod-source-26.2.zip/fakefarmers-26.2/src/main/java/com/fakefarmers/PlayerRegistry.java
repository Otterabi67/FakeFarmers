package com.fakefarmers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

/**
 * Merkt sich (persistent), welche Namen von ECHTEN Spielern stammen und welche Namen
 * von Bots benutzt wurden. Das ist noetig, damit ein frueher gespawnter Bot nicht selbst
 * als "ehemaliger Spieler" gilt (Bots speichern beim Entfernen ebenfalls Spielerdaten).
 *
 * Datei: config/fakefarmers-registry.json
 */
public final class PlayerRegistry {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("fakefarmers-registry.json");

	private static Data data;

	private static final class Data {
		Set<String> realPlayers = new TreeSet<>();
		Set<String> botNames = new TreeSet<>();
	}

	private PlayerRegistry() {
	}

	private static String key(String name) {
		return name.toLowerCase(Locale.ROOT);
	}

	private static synchronized Data data() {
		if (data == null) {
			data = load();
		}
		return data;
	}

	private static Data load() {
		if (Files.exists(FILE)) {
			try (Reader reader = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
				Data loaded = GSON.fromJson(reader, Data.class);
				if (loaded != null) {
					if (loaded.realPlayers == null) {
						loaded.realPlayers = new TreeSet<>();
					}
					if (loaded.botNames == null) {
						loaded.botNames = new TreeSet<>();
					}
					return loaded;
				}
			} catch (Exception e) {
				FakeFarmersMod.LOGGER.warn("Konnte fakefarmers-registry.json nicht lesen, starte mit leerer Registry.", e);
			}
		}
		return new Data();
	}

	private static void save(Data d) {
		try {
			Files.createDirectories(FILE.getParent());
			try (Writer writer = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
				GSON.toJson(d, writer);
			}
		} catch (IOException e) {
			FakeFarmersMod.LOGGER.warn("Konnte fakefarmers-registry.json nicht speichern.", e);
		}
	}

	/** Ein echter Spieler ist beigetreten: Name als "echt" merken (und als Bot-Namen austragen). */
	public static synchronized void recordRealPlayer(String name) {
		Data d = data();
		String k = key(name);
		boolean changed = d.realPlayers.add(k);
		changed |= d.botNames.remove(k);
		if (changed) {
			save(d);
		}
	}

	/** Ein Bot wurde mit diesem Namen gespawnt. */
	public static synchronized void recordBot(String name) {
		Data d = data();
		String k = key(name);
		if (!d.realPlayers.contains(k) && d.botNames.add(k)) {
			save(d);
		}
	}

	public static synchronized boolean isKnownRealPlayer(String name) {
		return data().realPlayers.contains(key(name));
	}

	public static synchronized boolean isKnownBot(String name) {
		return data().botNames.contains(key(name));
	}
}
