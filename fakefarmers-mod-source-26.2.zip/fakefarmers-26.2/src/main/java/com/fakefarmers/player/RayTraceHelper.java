package com.fakefarmers.player;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;
import java.util.function.Predicate;

/**
 * Ermittelt, worauf ein Spieler gerade "zeigt" (Block oder Entity innerhalb der Reichweite).
 */
public final class RayTraceHelper {

	private RayTraceHelper() {
	}

	public static HitResult rayTrace(Entity source, double reach) {
		Vec3 eye = source.getEyePosition(1.0F);
		Vec3 look = source.getViewVector(1.0F).scale(reach);
		Vec3 end = eye.add(look);

		BlockHitResult blockHit = source.level().clip(
			new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, source));

		double maxSqDistance = reach * reach;
		if (blockHit != null) {
			maxSqDistance = blockHit.getLocation().distanceToSqr(eye);
		}

		AABB searchBox = source.getBoundingBox().expandTowards(look).inflate(1.0);
		EntityHitResult entityHit = rayTraceEntities(source, eye, end, searchBox,
			e -> !e.isSpectator() && e.isPickable(), maxSqDistance);

		return entityHit == null ? blockHit : entityHit;
	}

	private static EntityHitResult rayTraceEntities(Entity source, Vec3 start, Vec3 end, AABB box,
													Predicate<Entity> predicate, double maxSqDistance) {
		Level level = source.level();
		double targetDistance = maxSqDistance;
		Entity target = null;
		Vec3 targetHitPos = null;

		for (Entity current : level.getEntities(source, box, predicate)) {
			AABB currentBox = current.getBoundingBox().inflate(current.getPickRadius());
			Optional<Vec3> currentHit = currentBox.clip(start, end);

			if (currentBox.contains(start)) {
				if (targetDistance >= 0) {
					target = current;
					targetHitPos = currentHit.orElse(start);
					targetDistance = 0;
				}
			} else if (currentHit.isPresent()) {
				Vec3 hitPos = currentHit.get();
				double distance = start.distanceToSqr(hitPos);
				if (distance < targetDistance || targetDistance == 0) {
					if (current.getRootVehicle() == source.getRootVehicle()) {
						if (targetDistance == 0) {
							target = current;
							targetHitPos = hitPos;
						}
					} else {
						target = current;
						targetHitPos = hitPos;
						targetDistance = distance;
					}
				}
			}
		}
		return target == null ? null : new EntityHitResult(target, targetHitPos);
	}
}
