package com.fakefarmers.player;

import com.fakefarmers.FakeFarmersMod;
import com.fakefarmers.PlayerRegistry;
import com.fakefarmers.network.FakeClientConnection;
import com.mojang.authlib.GameProfile;
import net.minecraft.network.DisconnectionDetails;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.game.ClientboundEntityPositionSyncPacket;
import net.minecraft.network.protocol.game.ClientboundRotateHeadPacket;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.util.ProblemReporter;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.item.component.ResolvableProfile;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.level.storage.TagValueInput;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CompletableFuture;

/**
 * Ein Spieler ohne echten Client (Bot). Wird nicht in der Spielerliste (Tab) angezeigt.
 */
public class FakePlayerEntity extends ServerPlayer {

	/** Namen, die gerade gespawnt werden (Profil wird asynchron geladen). */
	private static final Set<String> SPAWNING = ConcurrentHashMap.newKeySet();

	/** Wird von PlayerListMixin beim Platzieren aufgerufen, um die Startposition zu setzen. */
	public Runnable fixStartingPosition = () -> {
	};

	public final FakePlayerActionPack actionPack;

	/** Spieler, der den Bot gespawnt hat (null = Konsole/Command-Block). Nur Besitzer und Operatoren duerfen ihn steuern. */
	public UUID ownerUuid;

	public static boolean isSpawning(String name) {
		return SPAWNING.contains(name);
	}

	public static int spawningCount() {
		return SPAWNING.size();
	}

	/**
	 * Spawnt einen Bot. Das Profil (Skin) wird asynchron aufgeloest, der Bot erscheint kurz danach.
	 */
	public static void spawn(MinecraftServer server, String username, UUID uuid, UUID owner, Vec3 pos, float yaw, float pitch,
							 ResourceKey<Level> dimension, GameType gameMode, boolean flying) {
		ServerLevel level = server.getLevel(dimension);
		GameProfile fallbackProfile = new GameProfile(uuid, username);

		// Name sperren, solange das Profil geladen wird (verhindert doppeltes Spawnen)
		SPAWNING.add(username);

		fetchGameProfile(server, uuid).whenCompleteAsync((resolved, error) -> {
			SPAWNING.remove(username);
			if (error != null) {
				FakeFarmersMod.LOGGER.warn("Konnte Profil fuer Bot {} nicht laden.", username, error);
				return;
			}

			GameProfile profile = resolved.name().isEmpty() ? fallbackProfile : resolved;

			FakePlayerEntity bot = new FakePlayerEntity(server, level, profile);
			bot.ownerUuid = owner;
			bot.fixStartingPosition = () -> bot.snapTo(pos.x, pos.y, pos.z, yaw, pitch);

			PlayerRegistry.recordBot(username);
			server.getPlayerList().placeNewPlayer(
				new FakeClientConnection(PacketFlow.SERVERBOUND),
				bot,
				new CommonListenerCookie(profile, 0, bot.clientInformation(), false));

			loadSavedData(bot);
			bot.stopRiding(); // sonst sitzt der Bot nach dem Laden wieder auf einem Fahrzeug
			bot.teleportTo(level, pos.x, pos.y, pos.z, Set.of(), yaw, pitch, true);
			bot.setHealth(20.0F);
			bot.unsetRemoved();
			bot.getAttribute(Attributes.STEP_HEIGHT).setBaseValue(0.6F);
			bot.gameMode.changeGameModeForPlayer(gameMode);
			server.getPlayerList().broadcastAll(
				new ClientboundRotateHeadPacket(bot, (byte) (bot.yHeadRot * 256 / 360)), dimension);
			server.getPlayerList().broadcastAll(ClientboundEntityPositionSyncPacket.of(bot), dimension);
			bot.entityData.set(DATA_PLAYER_MODE_CUSTOMISATION, (byte) 0x7f); // alle Skin-Layer anzeigen
			bot.getAbilities().flying = flying;
		}, server);
	}

	private static CompletableFuture<GameProfile> fetchGameProfile(MinecraftServer server, UUID uuid) {
		ResolvableProfile unresolved = ResolvableProfile.createUnresolved(uuid);
		return unresolved.resolveProfile(server.services().profileResolver());
	}

	private static void loadSavedData(FakePlayerEntity bot) {
		try (ProblemReporter.ScopedCollector collector =
				 new ProblemReporter.ScopedCollector(bot.problemPath(), FakeFarmersMod.LOGGER)) {
			Optional<ValueInput> input = bot.level().getServer().getPlayerList()
				.loadPlayerData(bot.nameAndId())
				.map(tag -> TagValueInput.create(collector, bot.registryAccess(), tag));
			input.ifPresent(value -> {
				bot.load(value);
				bot.loadAndSpawnEnderPearls(value);
				bot.loadAndSpawnParentVehicle(value);
			});
		}
	}

	/** Fuer das Respawn-Redirect im PlayerListMixin. */
	public static FakePlayerEntity respawnFake(MinecraftServer server, ServerLevel level, GameProfile profile) {
		return new FakePlayerEntity(server, level, profile);
	}

	private FakePlayerEntity(MinecraftServer server, ServerLevel level, GameProfile profile) {
		super(server, level, profile, ClientInformation.createDefault());
		this.actionPack = new FakePlayerActionPack(this);
		this.actionPack.stopAll();
	}

	// ------------------------------------------------------------------ Verhalten

	/** Bots erscheinen nicht in der Spielerliste (Tab). */
	@Override
	public boolean allowsListing() {
		return false;
	}

	@Override
	public String getIpAddress() {
		return "127.0.0.1";
	}

	@Override
	public void kill(ServerLevel level) {
		kill(Component.literal("Entfernt"));
	}

	/** Entfernt den Bot (wie ein Disconnect). */
	public void kill(Component reason) {
		shakeOff();

		if (reason.getContents() instanceof TranslatableContents text
			&& text.getKey().equals("multiplayer.disconnect.duplicate_login")) {
			this.connection.onDisconnect(new DisconnectionDetails(reason));
		} else {
			MinecraftServer server = this.level().getServer();
			server.schedule(new TickTask(server.getTickCount(), () ->
				this.connection.onDisconnect(new DisconnectionDetails(reason))));
		}
	}

	@Override
	public void tick() {
		// Aktionen (Schlagen, Springen, ...) vor dem normalen Tick anwenden
		this.actionPack.onUpdate();

		if (this.level().getServer().getTickCount() % 10 == 0) {
			this.connection.resetPosition();
			this.level().getChunkSource().move(this);
		}
		try {
			super.tick();
			this.doTick();
		} catch (NullPointerException ignored) {
			// kann bei bestimmten Server-Forks auftreten; der Server soll deshalb nicht abstuerzen
		}
	}

	private void shakeOff() {
		if (getVehicle() instanceof Player) {
			stopRiding();
		}
		for (Entity passenger : getIndirectPassengers()) {
			if (passenger instanceof Player) {
				passenger.stopRiding();
			}
		}
	}

	/** Stirbt ein Bot, wird er entfernt (er hat keinen Client, der respawnen koennte). */
	@Override
	public void die(DamageSource cause) {
		shakeOff();
		super.die(cause);
		setHealth(20);
		this.foodData = new FoodData();
		kill(this.getCombatTracker().getDeathMessage());
	}

	@Override
	public ServerPlayer teleport(TeleportTransition transition) {
		super.teleport(transition);
		if (wonGame) {
			ServerboundClientCommandPacket packet =
				new ServerboundClientCommandPacket(ServerboundClientCommandPacket.Action.PERFORM_RESPAWN);
			connection.handleClientCommand(packet);
		}

		// Falls oben respawnt wurde, wurde *this* ersetzt; die neue Instanz haengt an unserer Verbindung.
		if (connection.player.isChangingDimension()) {
			connection.player.hasChangedDimension();
		}
		return connection.player;
	}
}
