package com.fakefarmers.player;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ClientboundSetHeldSlotPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

/**
 * Steuert die "Tastendruecke" eines Bots: Schlagen, Benutzen, Springen, Laufen, Schleichen usw.
 * Die Logik orientiert sich am Verhalten eines echten Clients.
 */
public class FakePlayerActionPack {

	private final ServerPlayer player;

	private final Map<ActionType, Action> actions = new EnumMap<>(ActionType.class);

	private BlockPos currentBlock;
	private int blockHitDelay;
	private float curBlockDamageMP;

	private boolean sneaking;
	private boolean sprinting;
	private float forward;
	private float strafing;

	private int itemUseCooldown;

	public FakePlayerActionPack(ServerPlayer player) {
		this.player = player;
	}

	// ------------------------------------------------------------------ Steuerung

	/** Startet (oder ersetzt) eine Aktion. action == null stoppt sie. */
	public FakePlayerActionPack start(ActionType type, Action action) {
		Action previous = actions.remove(type);
		if (previous != null) {
			type.stop(this, previous);
		}
		if (action != null) {
			actions.put(type, action);
		}
		return this;
	}

	public FakePlayerActionPack setSneaking(boolean value) {
		sneaking = value;
		player.setShiftKeyDown(value);
		if (sprinting && sneaking) {
			setSprinting(false);
		}
		return this;
	}

	public FakePlayerActionPack setSprinting(boolean value) {
		sprinting = value;
		player.setSprinting(value);
		if (sneaking && sprinting) {
			setSneaking(false);
		}
		return this;
	}

	public FakePlayerActionPack setForward(float value) {
		forward = value;
		return this;
	}

	public FakePlayerActionPack setStrafing(float value) {
		strafing = value;
		return this;
	}

	public FakePlayerActionPack look(Direction direction) {
		return switch (direction) {
			case NORTH -> look(180, 0);
			case SOUTH -> look(0, 0);
			case EAST -> look(-90, 0);
			case WEST -> look(90, 0);
			case UP -> look(player.getYRot(), -90);
			case DOWN -> look(player.getYRot(), 90);
		};
	}

	public FakePlayerActionPack look(float yaw, float pitch) {
		player.setYRot(yaw % 360);
		player.setXRot(Mth.clamp(pitch, -90, 90));
		return this;
	}

	public FakePlayerActionPack stopMovement() {
		setSneaking(false);
		setSprinting(false);
		forward = 0.0F;
		strafing = 0.0F;
		return this;
	}

	public FakePlayerActionPack stopAll() {
		for (Map.Entry<ActionType, Action> entry : new HashMap<>(actions).entrySet()) {
			entry.getKey().stop(this, entry.getValue());
		}
		actions.clear();
		return stopMovement();
	}

	/** Waehlt einen Hotbar-Slot (1-9). */
	public FakePlayerActionPack setSlot(int slot) {
		player.getInventory().setSelectedSlot(slot - 1);
		player.connection.send(new ClientboundSetHeldSlotPacket(slot - 1));
		return this;
	}

	/** Wirft den Gegenstand im aktuell gewaehlten Slot ab (ein Stueck oder ganzen Stack). */
	public FakePlayerActionPack dropSelected(boolean wholeStack) {
		player.resetLastActionTime();
		player.drop(wholeStack);
		return this;
	}

	/** Wirft das gesamte Inventar ab. */
	public FakePlayerActionPack dropEverything() {
		Inventory inv = player.getInventory();
		for (int i = inv.getContainerSize() - 1; i >= 0; i--) {
			if (!inv.getItem(i).isEmpty()) {
				player.drop(inv.removeItem(i, inv.getItem(i).getCount()), false, true);
			}
		}
		return this;
	}

	public String describe() {
		StringBuilder sb = new StringBuilder();
		for (Map.Entry<ActionType, Action> e : actions.entrySet()) {
			if (!sb.isEmpty()) {
				sb.append(", ");
			}
			sb.append(e.getKey().name().toLowerCase()).append(" (").append(e.getValue().describe()).append(")");
		}
		if (forward > 0) {
			append(sb, "vorwaerts");
		} else if (forward < 0) {
			append(sb, "rueckwaerts");
		}
		if (strafing > 0) {
			append(sb, "links");
		} else if (strafing < 0) {
			append(sb, "rechts");
		}
		if (sneaking) {
			append(sb, "schleichen");
		}
		if (sprinting) {
			append(sb, "sprinten");
		}
		return sb.isEmpty() ? "steht still" : sb.toString();
	}

	private static void append(StringBuilder sb, String text) {
		if (!sb.isEmpty()) {
			sb.append(", ");
		}
		sb.append(text);
	}

	// ------------------------------------------------------------------ Tick

	/** Wird jeden Tick des Bots aufgerufen. */
	public void onUpdate() {
		Map<ActionType, Boolean> attempts = new HashMap<>();
		actions.values().removeIf(a -> a.done);

		for (Map.Entry<ActionType, Action> entry : actions.entrySet()) {
			ActionType type = entry.getKey();
			Action action = entry.getValue();

			// Angriff ueberspringen, wenn "Benutzen" in diesem Tick erfolgreich war
			if (!(attempts.getOrDefault(ActionType.USE, false) && type == ActionType.ATTACK)) {
				Boolean status = action.tick(this, type);
				if (status != null) {
					attempts.put(type, status);
				}
			}
			// Benutzen nochmal versuchen, wenn der Angriff geklappt hat, aber Benutzen nicht
			if (type == ActionType.ATTACK
				&& attempts.getOrDefault(ActionType.ATTACK, false)
				&& !attempts.getOrDefault(ActionType.USE, true)) {
				Action using = actions.get(ActionType.USE);
				if (using != null) {
					using.retry(this, ActionType.USE);
				}
			}
		}

		float velocity = sneaking ? 0.3F : 1.0F;
		player.zza = forward * velocity;
		player.xxa = strafing * velocity;
	}

	static HitResult getTarget(ServerPlayer player) {
		double reach = player.gameMode.isCreative() ? 5 : 4.5;
		return RayTraceHelper.rayTrace(player, reach);
	}

	// ------------------------------------------------------------------ Aktionstypen

	public enum ActionType {
		USE {
			@Override
			boolean execute(FakePlayerActionPack ap, Action action) {
				ServerPlayer player = ap.player;
				if (ap.itemUseCooldown > 0) {
					ap.itemUseCooldown--;
					return true;
				}
				if (player.isUsingItem()) {
					return true;
				}
				HitResult hit = getTarget(player);
				for (InteractionHand hand : InteractionHand.values()) {
					switch (hit.getType()) {
						case BLOCK: {
							player.resetLastActionTime();
							ServerLevel world = player.level();
							BlockHitResult blockHit = (BlockHitResult) hit;
							BlockPos pos = blockHit.getBlockPos();
							Direction side = blockHit.getDirection();
							if (pos.getY() < world.getMaxY() - (side == Direction.UP ? 1 : 0) && world.mayInteract(player, pos)) {
								InteractionResult result = player.gameMode.useItemOn(player, world, player.getItemInHand(hand), hand, blockHit);
								if (result instanceof InteractionResult.Success success) {
									if (success.swingSource() == InteractionResult.SwingSource.SERVER) {
										player.swing(hand);
									}
									ap.itemUseCooldown = 3;
									return true;
								}
							}
							break;
						}
						case ENTITY: {
							player.resetLastActionTime();
							EntityHitResult entityHit = (EntityHitResult) hit;
							Entity entity = entityHit.getEntity();
							Vec3 relative = entityHit.getLocation().subtract(entity.getX(), entity.getY(), entity.getZ());
							if (entity.interact(player, hand, relative).consumesAction()) {
								ap.itemUseCooldown = 3;
								return true;
							}
							InteractionResult interaction = player.interactOn(entity, hand, relative);
							if (interaction.consumesAction()) {
								ap.itemUseCooldown = 3;
								return true;
							}
							break;
						}
						default:
							break;
					}
					ItemStack handItem = player.getItemInHand(hand);
					if (player.gameMode.useItem(player, player.level(), handItem, hand).consumesAction()) {
						ap.itemUseCooldown = 3;
						return true;
					}
				}
				return false;
			}

			@Override
			void inactiveTick(FakePlayerActionPack ap, Action action) {
				ap.itemUseCooldown = 0;
				ap.player.releaseUsingItem();
			}
		},

		ATTACK {
			@Override
			boolean execute(FakePlayerActionPack ap, Action action) {
				ServerPlayer player = ap.player;
				HitResult hit = getTarget(player);
				switch (hit.getType()) {
					case ENTITY: {
						EntityHitResult entityHit = (EntityHitResult) hit;
						// "continuous" entspricht gehaltener Maustaste: schlaegt keine Entities.
						if (!action.continuous) {
							player.attack(entityHit.getEntity());
							player.swing(InteractionHand.MAIN_HAND);
						}
						player.resetAttackStrengthTicker();
						player.resetLastActionTime();
						return true;
					}
					case BLOCK: {
						if (ap.blockHitDelay > 0) {
							ap.blockHitDelay--;
							return false;
						}
						BlockHitResult blockHit = (BlockHitResult) hit;
						BlockPos pos = blockHit.getBlockPos();
						Direction side = blockHit.getDirection();
						if (player.blockActionRestricted(player.level(), pos, player.gameMode.getGameModeForPlayer())) {
							return false;
						}
						if (ap.currentBlock != null && player.level().getBlockState(ap.currentBlock).isAir()) {
							ap.currentBlock = null;
							return false;
						}
						BlockState state = player.level().getBlockState(pos);
						boolean blockBroken = false;
						if (player.gameMode.getGameModeForPlayer().isCreative()) {
							player.gameMode.handleBlockBreakAction(pos, ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, side, player.level().getMaxY(), -1);
							ap.blockHitDelay = 5;
							blockBroken = true;
						} else if (ap.currentBlock == null || !ap.currentBlock.equals(pos)) {
							if (ap.currentBlock != null) {
								player.gameMode.handleBlockBreakAction(ap.currentBlock, ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, side, player.level().getMaxY(), -1);
							}
							player.gameMode.handleBlockBreakAction(pos, ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, side, player.level().getMaxY(), -1);
							boolean notAir = !state.isAir();
							if (notAir && ap.curBlockDamageMP == 0) {
								state.attack(player.level(), pos, player);
							}
							if (notAir && state.getDestroyProgress(player, player.level(), pos) >= 1) {
								ap.currentBlock = null;
								blockBroken = true; // sofort abgebaut
							} else {
								ap.currentBlock = pos;
								ap.curBlockDamageMP = 0;
							}
						} else {
							ap.curBlockDamageMP += state.getDestroyProgress(player, player.level(), pos);
							if (ap.curBlockDamageMP >= 1) {
								player.gameMode.handleBlockBreakAction(pos, ServerboundPlayerActionPacket.Action.STOP_DESTROY_BLOCK, side, player.level().getMaxY(), -1);
								ap.currentBlock = null;
								ap.blockHitDelay = 5;
								blockBroken = true;
							}
							player.level().destroyBlockProgress(-1, pos, (int) (ap.curBlockDamageMP * 10));
						}
						player.resetLastActionTime();
						player.swing(InteractionHand.MAIN_HAND);
						return blockBroken;
					}
					default:
						break;
				}
				return false;
			}

			@Override
			void inactiveTick(FakePlayerActionPack ap, Action action) {
				if (ap.currentBlock == null) {
					return;
				}
				ServerPlayer player = ap.player;
				player.level().destroyBlockProgress(-1, ap.currentBlock, -1);
				player.gameMode.handleBlockBreakAction(ap.currentBlock, ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, Direction.DOWN, player.level().getMaxY(), -1);
				ap.currentBlock = null;
			}
		},

		JUMP {
			@Override
			boolean execute(FakePlayerActionPack ap, Action action) {
				ServerPlayer player = ap.player;
				if (action.limit == 1) {
					if (player.onGround()) {
						player.jumpFromGround();
					} else if (!player.onClimbable()) {
						player.tryToStartFallFlying();
					}
				} else {
					player.setJumping(true);
				}
				return false;
			}

			@Override
			void inactiveTick(FakePlayerActionPack ap, Action action) {
				ap.player.setJumping(false);
			}
		};

		abstract boolean execute(FakePlayerActionPack ap, Action action);

		void inactiveTick(FakePlayerActionPack ap, Action action) {
		}

		void stop(FakePlayerActionPack ap, Action action) {
			inactiveTick(ap, action);
		}
	}

	// ------------------------------------------------------------------ Aktion (Wiederholungsmuster)

	public static class Action {
		public boolean done = false;
		public final int limit;
		public final int interval;
		private final boolean continuous;
		private int count;
		private int next;

		private Action(int limit, int interval, boolean continuous) {
			this.limit = limit;
			this.interval = interval;
			this.continuous = continuous;
			this.next = interval;
		}

		/** Einmal ausfuehren. */
		public static Action once() {
			return new Action(1, 1, false);
		}

		/** Dauerhaft gehalten (jeden Tick), wie eine gedrueckt gehaltene Taste. */
		public static Action continuous() {
			return new Action(-1, 1, true);
		}

		/** Alle {@code ticks} Ticks einmal ausfuehren. */
		public static Action interval(int ticks) {
			return new Action(-1, Math.max(1, ticks), false);
		}

		String describe() {
			if (limit == 1) {
				return "einmal";
			}
			if (continuous) {
				return "dauerhaft";
			}
			return "alle " + interval + " Ticks";
		}

		Boolean tick(FakePlayerActionPack ap, ActionType type) {
			next--;
			Boolean result = null;
			if (next <= 0) {
				if (interval == 1 && !continuous) {
					// Entity muss einen Tick laufen duerfen, sonst hat die Aktion keinen Effekt
					if (!ap.player.isSpectator()) {
						type.inactiveTick(ap, this);
					}
				}
				if (!ap.player.isSpectator()) {
					result = type.execute(ap, this);
				}
				count++;
				if (count == limit) {
					type.stop(ap, this);
					done = true;
					return result;
				}
				next = interval;
			} else {
				if (!ap.player.isSpectator()) {
					type.inactiveTick(ap, this);
				}
			}
			return result;
		}

		void retry(FakePlayerActionPack ap, ActionType type) {
			if (!ap.player.isSpectator()) {
				type.execute(ap, this);
			}
			count++;
			if (count == limit) {
				type.stop(ap, this);
				done = true;
			}
		}
	}
}
