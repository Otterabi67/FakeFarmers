package com.fakefarmers;

import com.fakefarmers.command.FakePlayerCommand;
import com.fakefarmers.player.FakePlayerEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public final class FakeFarmersMod implements ModInitializer {

	public static final String MOD_ID = "fakefarmers";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		FakeFarmersConfig.get();

		CommandRegistrationCallback.EVENT.register((dispatcher, buildContext, selection) ->
			FakePlayerCommand.register(dispatcher));

		// Echte Spieler merken, damit ihre Namen spaeter nicht als Bot genutzt werden koennen.
		ServerPlayConnectionEvents.JOIN.register((listener, sender, server) -> {
			ServerPlayer player = listener.player;
			if (!(player instanceof FakePlayerEntity)) {
				PlayerRegistry.recordRealPlayer(player.getGameProfile().name());
			}
		});

		// Beim Stoppen alle Bots sauber entfernen, damit ihre Daten gespeichert werden.
		ServerLifecycleEvents.SERVER_STOPPING.register(FakeFarmersMod::removeAllBots);

		LOGGER.info("FakeFarmers geladen (Bot-Limit: {}).", FakeFarmersConfig.get().maxBots);
	}

	private static void removeAllBots(MinecraftServer server) {
		List<ServerPlayer> snapshot = List.copyOf(server.getPlayerList().getPlayers());
		for (ServerPlayer player : snapshot) {
			if (player instanceof FakePlayerEntity bot) {
				bot.kill(Component.literal("Server stoppt"));
			}
		}
	}
}
