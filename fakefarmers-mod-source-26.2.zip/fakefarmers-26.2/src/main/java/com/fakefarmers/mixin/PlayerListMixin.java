package com.fakefarmers.mixin;

import com.fakefarmers.network.FakePlayerNetHandler;
import com.fakefarmers.player.FakePlayerEntity;
import com.mojang.authlib.GameProfile;
import net.minecraft.network.Connection;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.server.players.PlayerList;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerList.class)
public abstract class PlayerListMixin {

	@Shadow
	@Final
	private MinecraftServer server;

	/** Setzt die Startposition des Bots, bevor der Server ihn in die Welt platziert. */
	@Inject(
		method = "placeNewPlayer",
		at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;level()Lnet/minecraft/server/level/ServerLevel;")
	)
	private void fakefarmers$fixStartingPos(Connection connection, ServerPlayer player, CommonListenerCookie cookie, CallbackInfo ci) {
		if (player instanceof FakePlayerEntity bot) {
			bot.fixStartingPosition.run();
		}
	}

	/** Bots bekommen einen Netzwerk-Handler ohne echte Verbindung. */
	@Redirect(
		method = "placeNewPlayer",
		at = @At(
			value = "NEW",
			target = "(Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/network/Connection;Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/server/network/CommonListenerCookie;)Lnet/minecraft/server/network/ServerGamePacketListenerImpl;"
		)
	)
	private ServerGamePacketListenerImpl fakefarmers$replaceNetworkHandler(MinecraftServer minecraftServer, Connection connection, ServerPlayer player, CommonListenerCookie cookie) {
		if (player instanceof FakePlayerEntity bot) {
			return new FakePlayerNetHandler(this.server, connection, bot, cookie);
		}
		return new ServerGamePacketListenerImpl(this.server, connection, player, cookie);
	}

	/** Verhindert, dass ein Bot nach einem Respawn (z.B. End-Credits) durch einen normalen, sichtbaren Spieler ersetzt wird. */
	@Redirect(
		method = "respawn",
		at = @At(
			value = "NEW",
			target = "(Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/server/level/ServerLevel;Lcom/mojang/authlib/GameProfile;Lnet/minecraft/server/level/ClientInformation;)Lnet/minecraft/server/level/ServerPlayer;"
		)
	)
	public ServerPlayer fakefarmers$makePlayerForRespawn(MinecraftServer minecraftServer, ServerLevel level, GameProfile profile, ClientInformation info, ServerPlayer oldPlayer, boolean keepData) {
		if (oldPlayer instanceof FakePlayerEntity) {
			return FakePlayerEntity.respawnFake(minecraftServer, level, profile);
		}
		return new ServerPlayer(minecraftServer, level, profile, info);
	}
}
