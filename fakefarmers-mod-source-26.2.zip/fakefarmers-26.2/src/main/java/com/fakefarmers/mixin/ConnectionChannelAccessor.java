package com.fakefarmers.mixin;

import io.netty.channel.Channel;
import net.minecraft.network.Connection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Erlaubt es, den (privaten) Netty-Channel einer Connection zu setzen,
 * damit die FakeClientConnection einen Dummy-Channel verwenden kann.
 */
@Mixin(Connection.class)
public interface ConnectionChannelAccessor {

	@Accessor("channel")
	void fakefarmers$setChannel(Channel channel);
}
