package com.fakefarmers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Einfache JSON-Konfiguration (config/fakefarmers.json).
 */
public final class FakeFarmersConfig {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("fakefarmers.json");

	private static FakeFarmersConfig instance;

	/** Maximale Anzahl gleichzeitig aktiver Fake-Spieler. */
	public int maxBots = 10;

	/** Wenn true, duerfen Namen von Spielern, die schon auf dem Server waren, nicht als Bot gespawnt werden. */
	public boolean blockFormerPlayerNames = true;

	/**
	 * Spieler (UUID -> letzter bekannter Name), die Bots spawnen duerfen.
	 * Operatoren (Level 2) duerfen immer, auch ohne Eintrag.
	 */
	public Map<String, String> allowedPlayers = new LinkedHashMap<>();

	public static synchronized FakeFarmersConfig get() {
		if (instance == null) {
			instance = load();
		}
		return instance;
	}

	private static FakeFarmersConfig load() {
		if (Files.exists(FILE)) {
			try (Reader reader = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
				FakeFarmersConfig loaded = GSON.fromJson(reader, FakeFarmersConfig.class);
				if (loaded != null) {
					if (loaded.maxBots < 0) {
						loaded.maxBots = 0;
					}
					if (loaded.allowedPlayers == null) {
						loaded.allowedPlayers = new LinkedHashMap<>();
					}
					return loaded;
				}
			} catch (Exception e) {
				FakeFarmersMod.LOGGER.warn("Konnte fakefarmers.json nicht lesen, verwende Standardwerte.", e);
			}
		}
		FakeFarmersConfig fresh = new FakeFarmersConfig();
		fresh.save();
		return fresh;
	}

	public synchronized void save() {
		try {
			Files.createDirectories(FILE.getParent());
			try (Writer writer = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
				GSON.toJson(this, writer);
			}
		} catch (IOException e) {
			FakeFarmersMod.LOGGER.warn("Konnte fakefarmers.json nicht speichern.", e);
		}
	}
}
