package com.fakefarmers.network;

import com.fakefarmers.mixin.ConnectionChannelAccessor;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketListener;
import net.minecraft.network.ProtocolInfo;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;

/**
 * Netzwerkverbindung ohne echten Client: alle Pakete werden verworfen.
 */
public class FakeClientConnection extends Connection {

	public FakeClientConnection(PacketFlow flow) {
		super(flow);
		((ConnectionChannelAccessor) (Object) this).fakefarmers$setChannel(new EmbeddedChannel());
	}

	@Override
	public void setReadOnly() {
	}

	@Override
	public void handleDisconnection() {
	}

	@Override
	public void send(Packet<?> packet, ChannelFutureListener listener, boolean flush) {
	}

	@Override
	public void setListenerForServerboundHandshake(PacketListener listener) {
	}

	@Override
	public <T extends PacketListener> void setupInboundProtocol(ProtocolInfo<T> protocolInfo, T listener) {
	}
}
