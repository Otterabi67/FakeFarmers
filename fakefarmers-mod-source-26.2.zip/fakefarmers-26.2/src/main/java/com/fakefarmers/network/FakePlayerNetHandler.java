package com.fakefarmers.network;

import com.fakefarmers.player.FakePlayerEntity;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.PositionMoveRotation;
import net.minecraft.world.entity.Relative;

import java.util.Set;

public class FakePlayerNetHandler extends ServerGamePacketListenerImpl {

	public FakePlayerNetHandler(MinecraftServer server, Connection connection, ServerPlayer player, CommonListenerCookie cookie) {
		super(server, connection, player, cookie);
	}

	/**
	 * Es gibt keine echte Verbindung, die man trennen koennte.
	 *  - Idle-Timeout: wird ignoriert, denn Bots sollen ja gerade AFK stehen duerfen.
	 *  - Doppelter Login (ein echter Spieler mit gleichem Namen): der Bot wird entfernt.
	 *  - Alle anderen Gruende werden ignoriert.
	 */
	@Override
	public void disconnect(Component reason) {
		if (reason.getContents() instanceof TranslatableContents contents) {
			String key = contents.getKey();
			if (key.equals("multiplayer.disconnect.idling")) {
				this.player.resetLastActionTime();
			} else if (key.equals("multiplayer.disconnect.duplicate_login")) {
				((FakePlayerEntity) this.player).kill(reason);
			}
		}
	}

	@Override
	public void teleport(PositionMoveRotation positionMoveRotation, Set<Relative> relatives) {
		super.teleport(positionMoveRotation, relatives);
		if (this.player.level().getPlayerByUUID(this.player.getUUID()) != null) {
			resetPosition();
			this.player.level().getChunkSource().move(this.player);
		}
	}
}
