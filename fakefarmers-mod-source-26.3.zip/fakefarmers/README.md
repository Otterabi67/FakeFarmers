# FakeFarmers (Fabric, Minecraft 26.3)

Serverseitige Mod, die **Fake-Spieler (Bots)** spawnt, die z. B. an Farmen AFK stehen.
Alle Funktionen sind per Command steuerbar. Es wird nur **Fabric API** als Abhängigkeit benötigt,
**nicht** Carpet.

## Wichtig: Die .jar muss einmal selbst gebaut werden

Dieses Projekt wurde in einer Umgebung ohne Zugriff auf die Mojang-/Fabric-/Gradle-Server erstellt.
Deshalb liegt hier der komplette, fertige **Quellcode** bei – die `.jar` baust du mit einem Befehl selbst:

**Voraussetzungen:** JDK 25 und Internetzugang (Gradle lädt Minecraft + Fabric automatisch).

```bash
# Linux / macOS
./gradlew build

# Windows
gradlew.bat build
```

Die fertige Mod liegt danach unter **`build/libs/fakefarmers-1.0.0.jar`**
(`...-sources.jar` ignorieren).

Der erste Build dauert einige Minuten (Download + Entschleierung/Mappings).

## Installation

1. Fabric Loader **0.19.5+** für Minecraft **26.3** auf dem Server installieren.
2. **Fabric API `0.161.0+26.3`** (oder neuer) in den `mods`-Ordner legen.
3. `fakefarmers-1.0.0.jar` in den `mods`-Ordner legen.
4. Server starten. Die Config wird unter `config/fakefarmers.json` angelegt.

Läuft dein Server auf einer anderen Minecraft-Version, passe `minecraft_version`,
`fabric_api_version` (und ggf. `loader_version`) in `gradle.properties` an
(aktuelle Werte: https://fabricmc.net/develop).
Bei einer anderen Version können einzelne Minecraft-Klassen/Methoden anders heißen
und müssten im Code angepasst werden.

## Befehle

Kurzform: `/fp` statt `/fakeplayer`. Wer die Befehle benutzen darf, siehe Abschnitt **Berechtigungen**.

### Verwaltung

| Befehl | Wirkung |
|---|---|
| `/fakeplayer spawn <name>` | Bot an deiner Position (Blickrichtung, Spielmodus) spawnen |
| `/fakeplayer spawn <name> at <x> <y> <z>` | Bot an einer Position spawnen (`~` erlaubt) |
| `/fakeplayer <name> kill` | Bot entfernen |
| `/fakeplayer killall` | Alle Bots entfernen |
| `/fakeplayer list` | Aktive Bots und Limit anzeigen |
| `/fakeplayer limit` | Aktuelles Bot-Limit anzeigen |
| `/fakeplayer limit <zahl>` | Bot-Limit setzen (wird gespeichert) |
| `/fakeplayer allowformernames [true\|false]` | Namen ehemaliger Spieler erlauben/blockieren (Standard: blockiert) |

### Berechtigungen (nur Operatoren)

| Befehl | Wirkung |
|---|---|
| `/fakeplayer permission add <spieler>` | Spieler darf Bots spawnen (Spieler muss online sein) |
| `/fakeplayer permission remove <name>` | Erlaubnis entziehen |
| `/fakeplayer permission list` | Alle erlaubten Spieler anzeigen |

### Steuerung eines Bots

| Befehl | Wirkung |
|---|---|
| `/fakeplayer <name> attack once` | Einmal schlagen / Block anschlagen |
| `/fakeplayer <name> attack interval <ticks>` | Alle *n* Ticks schlagen (Mob-Farmen: z. B. `12`) |
| `/fakeplayer <name> attack continuous` | Linke Maustaste halten (baut Blöcke ab, schlägt **keine** Entities) |
| `/fakeplayer <name> attack stop` | Schlagen beenden |
| `/fakeplayer <name> use once\|interval <ticks>\|continuous\|stop` | Rechtsklick (Items, Blöcke, Entities) |
| `/fakeplayer <name> jump once\|interval <ticks>\|continuous\|stop` | Springen |
| `/fakeplayer <name> sneak true\|false` | Schleichen |
| `/fakeplayer <name> sprint true\|false` | Sprinten |
| `/fakeplayer <name> move forward\|backward\|left\|right\|stop` | Laufen |
| `/fakeplayer <name> look north\|south\|east\|west\|up\|down` | Blickrichtung |
| `/fakeplayer <name> hotbar <1-9>` | Hotbar-Slot wählen |
| `/fakeplayer <name> drop [stack\|all]` | Item / Stack / gesamtes Inventar abwerfen |
| `/fakeplayer <name> status` | Aktive Aktionen anzeigen |
| `/fakeplayer <name> stop` | Alle Aktionen beenden |

Items bekommt ein Bot wie jeder Spieler, z. B. `/give Bot1 diamond_sword`.

**Typischer Ablauf für eine AFK-Farm:** An den gewünschten Platz stellen, in die richtige Richtung
schauen, `/fakeplayer spawn Bot1` ausführen. Fertig. Optional z. B. `/fakeplayer Bot1 attack interval 12`.

## Berechtigungen

- **Operatoren (Level 2)**, Konsole und Command-Blöcke dürfen immer alles.
- **Erlaubte Spieler** (per `/fakeplayer permission add`) dürfen Bots spawnen und **ihre eigenen**
  Bots steuern, auflisten und entfernen. Fremde Bots können sie nicht steuern.
- Nur Operatoren dürfen: `limit <zahl>`, `allowformernames`, `permission ...`, und alle Bots steuern/entfernen.
- Alle anderen Spieler sehen den Befehl gar nicht (er erscheint ihnen als unbekannt).
- Entziehst du jemandem die Erlaubnis, bleiben seine schon gespawnten Bots bestehen;
  ein Operator kann sie mit `/fakeplayer <name> kill` entfernen.
- Das Bot-Limit gilt global für alle zusammen.
- Die Liste liegt in `config/fakefarmers.json` unter `allowedPlayers` (UUID → Name) und lässt sich
  dort auch bei gestopptem Server bearbeiten.

## Verhalten

- **Tab-Liste:** Bots werden dort nicht angezeigt (`allowsListing() = false`).
  Skin und Name im Spiel bleiben sichtbar. `/list` und der Spielerzähler in der Server-Liste
  können Bots weiterhin mitzählen – nutze `/fakeplayer list`.
- **Bot-Limit:** Standard 10, Änderung per Command oder in `config/fakefarmers.json` (`maxBots`).
  Gesetzt wird das Limit gegen aktive **und** gerade ladende Bots.
- **Keine ehemaligen Spieler:** Ein Name wird nicht gespawnt, wenn er zu einem echten Spieler gehört, der
  schon auf dem Server war. Erkannt wird das über
  (1) Spieler, die mit installierter Mod beigetreten sind (`config/fakefarmers-registry.json`),
  (2) vorhandene Spielerdaten im Weltordner, (3) Operatoren, (4) Whitelist-Einträge.
  Gebannte Namen werden immer blockiert. Namen, die schon früher von einem Bot dieser Mod
  genutzt wurden, dürfen wiederverwendet werden.
  Löschst du `fakefarmers-registry.json`, gelten alte Bot-Namen wieder als „bekannt“ (dann
  `allowformernames true` setzen oder einen neuen Namen wählen).
- **Tod:** Stirbt ein Bot, wird er entfernt (er hat keinen Client zum Respawnen). Einfach neu spawnen.
- **Neustart:** Bots werden beim Server-Stopp entfernt und müssen danach neu gespawnt werden.
  Inventar und Position werden wie bei normalen Spielern gespeichert und beim erneuten Spawnen geladen.
- **Idle-Timeout:** Ein gesetztes `player-idle-timeout` entfernt Bots **nicht**.
- **Doppelter Login:** Betritt ein echter Spieler mit gleichem Namen den Server, wird der Bot entfernt.
- **`attack continuous`** verhält sich wie gehaltene Maustaste und schlägt keine Mobs.
  Für Mob-Farmen `attack interval <ticks>` verwenden.

## Konfiguration (`config/fakefarmers.json`)

```json
{
  "maxBots": 10,
  "blockFormerPlayerNames": true,
  "allowedPlayers": {}
}
```

## Projektstruktur

```
src/main/java/com/fakefarmers/
  FakeFarmersMod.java          Einstiegspunkt, Events
  FakeFarmersConfig.java       Konfiguration
  PlayerRegistry.java          Merkt echte Spieler- und Bot-Namen
  NameGuard.java               Prüft, ob ein Bot-Name erlaubt ist
  command/FakePlayerCommand    Alle Befehle
  player/FakePlayerEntity      Der Bot (ServerPlayer-Subklasse)
  player/FakePlayerActionPack  Schlagen, Springen, Laufen, ...
  player/RayTraceHelper        Block-/Entity-Treffer
  network/                     Fake-Verbindung ohne echten Client
  mixin/                       3 kleine Mixins (Netzwerk-Handler, Channel, Knockback)
```

Die Bot-Technik (Fake-Verbindung, Mixin-Ziele, Action-Pack-Logik) orientiert sich an der
Arbeitsweise von [Fabric Carpet](https://github.com/gnembon/fabric-carpet) (MIT-Lizenz).
