package com.fakefarmers.mixin;

import com.fakefarmers.player.FakePlayerEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Player.class)
public abstract class PlayerKnockbackMixin {

	/**
	 * Stellt sicher, dass Schlaege von Spielern auch Bots zurueckstossen.
	 */
	@Redirect(
		method = "causeExtraKnockback",
		at = @At(
			value = "FIELD",
			target = "Lnet/minecraft/world/entity/Entity;syncVelocity:Z",
			ordinal = 0
		)
	)
	private boolean fakefarmers$velocityModifiedAndNotFakePlayer(Entity target) {
		return target.syncVelocity && !(target instanceof FakePlayerEntity);
	}
}
